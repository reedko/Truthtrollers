declare module "youtube-transcript-api" {
  const value: any;
  export = value;
}
