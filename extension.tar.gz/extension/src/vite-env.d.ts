/// <reference types="vite/client" />
declare module "@chakra-ui/react";
declare module "*.webp";
declare module "*.png";
declare module "*.jpg";
