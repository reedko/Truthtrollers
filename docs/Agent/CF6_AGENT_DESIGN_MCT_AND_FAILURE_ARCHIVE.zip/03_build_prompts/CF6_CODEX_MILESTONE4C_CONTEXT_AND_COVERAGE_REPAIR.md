# Codex Execution Prompt — CF6 Milestone 4C
## Combined Context-Economy and Article-Coverage Repair

Work from the VeriStrata repository root.

The F03 token audit is accepted.

Established facts:

- 11 model requests
- 135,817 input tokens
- 4,263 output tokens
- 140,080 total tokens
- full client-managed history
- no session, `conversationId`, or `previousResponseId`
- no mixed-state duplication bug
- repeated transcript replay caused the blow-up
- fixed seven-tool schema bundle: approximately 6,162 tokens per request
- `apply_package_patch`: approximately 3,604 schema tokens per request and never used
- `save_working_package`: approximately 1,801 schema tokens per request
- complete content-map result: approximately 3,100 tokens replayed through later turns
- exact source-read outputs and superseded full-package arguments were repeatedly replayed
- the article contained 404 source units, but the agent inspected only U0001–U0022
- the complete structural block map was available; the agent still anchored on the opening region
- the existing run cannot provide exact request-level usage for turns 1–10 because raw responses and request usage entries were discarded

The current architecture is mechanically agentic but economically and semantically unacceptable.

Do not run another live fixture until both repairs below pass offline gates:

1. bounded model-visible context;
2. article-wide inspection coverage before finalization.

Do not tune attribution, atomicity, treatment, supplier assignment, or claim wording in this milestone.

---

## 1. Governing objective

Repair the current manager loop so that:

- durable MySQL audit history remains complete;
- model-visible history contains only current decision-relevant state;
- tool schemas are not repeatedly advertised when illegal or irrelevant;
- the agent must account for all major article regions before finalization;
- the model still chooses its own next action among currently legal tools;
- no fixed extraction pipeline is introduced;
- one F03 verification run is projected below 45,000 input tokens before it is authorized.

Target input usage: approximately 30,000 tokens.

Hard projected ceiling before live execution: 45,000 input tokens.

---

## 2. Mandatory preflight

Before editing:

```bash
git status --short
git branch --show-current
git diff --stat
node --version
npm --version

cd backend
npm run typecheck:agents
npm run test:agents:claim-foundry-agent
npm run test:agents:claim-foundry-tools
npm run test:agents:claim-foundry-mysql
node --test experiments/cf5/*.test.js
```

Run relevant ArticleDocument/source-block/grounding/storage tests.

Inspect the accepted manager runtime, tool registration, schemas, persistence, state transitions, validation, finalization, and SDK support for:

- `callModelInputFilter`
- conditional tool enablement such as `isEnabled`
- request usage entries
- raw model responses
- model response IDs
- cached token reporting

Use the installed SDK types and implementation, not remembered examples.

Do not clean, stash, reset, switch branches, or commit.

---

## 3. Repair A: permanent request-level observability

Persist for every model request:

- model turn;
- response ID;
- exact input tokens;
- cached input tokens;
- uncached input tokens;
- output tokens;
- total tokens;
- model;
- tools exposed for that request;
- tool selected after that request;
- model-visible input hash;
- estimated model-visible input size by payload class;
- created timestamp.

Persist normalized request usage even if trace export fails.

Do not persist secrets or unrestricted raw provider objects.

Add a hard cumulative input-token budget enforced before the next model request. The runner must stop with typed `budget_exhausted` rather than overshoot materially.

Add tests proving request accounting survives process reload and trace-export failure.

---

## 4. Repair B: deterministic model-input filtering

Implement a deterministic `callModelInputFilter` or the exact installed-SDK equivalent.

The full durable audit ledger remains in MySQL.

Before each model request, construct a bounded model-visible state from typed persisted data:

- compact run identity and terminal status;
- remaining budgets;
- article-region coverage summary;
- current selected-claim summary or only currently relevant claim rows;
- active validation findings;
- latest relevant source-unit text;
- latest tool result or error;
- any unresolved review/abstention state.

Remove from later model requests:

- superseded complete package-save arguments;
- superseded package-save results;
- old content-map payloads after a compact coverage representation exists;
- old source text no longer needed for the current decision;
- old successful tool envelopes whose effects are already represented in persisted state;
- duplicate state/audit metadata.

Exact source text may be removed from the active transcript only when:

- its source-unit IDs remain persisted;
- any grounded semantic notes or claim rows are persisted;
- the text remains rereadable through `read_source_units`;
- tests prove the agent can reread it when validation or repair requires it.

Do not use a model-generated summary to decide what is discarded.

Do not erase the latest relevant failure or validation finding.

---

## 5. Repair C: reduce fixed tool-schema cost

The current seven-tool bundle costs approximately 6,162 tokens on every request. This alone prevents the input filter from reaching the token gate.

Implement state-dependent exposure of currently legal tools using the installed SDK’s supported conditional-tool mechanism.

This must remain agentic:

- the host may expose the set of actions legal in the current state;
- the model chooses among multiple legal actions;
- the host must not prescribe the exact next tool;
- do not encode a compulsory inspect → draft → validate → repair → finalize route.

Examples:

- before a working package exists, patch/finalize are unavailable;
- when no validation findings exist, patch is unavailable;
- when structural hard errors remain, complete finalization is unavailable;
- after terminal state, no domain tools are available;
- read and find remain available whenever further inspection is legal;
- save remains available when drafting/updating is legal;
- validate remains available when a package exists;
- abstention remains available under the accepted terminal rules.

Also redesign bulky schemas where safely possible.

### `save_working_package`

Avoid repeatedly advertising and transmitting an entire recursive package schema if a shallower bounded drafting contract can preserve the same semantic and structural guarantees.

Preferred direction:

- repository-owned identity, hashes, audit fields, and immutable metadata are filled from authorized context;
- the model supplies only semantic package content;
- use bounded claim-row upsert/remove operations or another explicit typed contract rather than repeated full-package replacement;
- do not expose arbitrary JSON patching;
- preserve all accepted validation and audit behavior.

### `apply_package_patch`

Do not advertise the entire 3,604-token discriminated union on turns where patching is impossible.

When patching is legal, consider shallow operation selection followed by operation-specific validation, provided the model still receives enough schema information to create a valid bounded repair.

No loss of patch safety is allowed.

Add tests proving conditional tool exposure does not become hard-coded choreography.

---

## 6. Repair D: compact tool result envelopes

Do not return bulky mutation state when the model only needs a compact decision result.

Keep full state and events in MySQL.

Return compact model-facing results such as:

- action status;
- changed object IDs;
- current package version/hash;
- compact coverage delta;
- active findings;
- remaining budgets;
- explicit next-state constraints;
- exact requested source text where applicable.

### Content map

F03’s `get_content_map` returned the complete block map, not a truncated map. Do not add pagination as though the original failure were missing access.

Instead return a compact article-wide map containing:

- total source-unit count;
- total block count;
- major structural regions;
- heading or structural label;
- start/end unit IDs;
- unit count;
- current inspection status;
- exact block detail only when requested or needed.

Preserve the full map in durable state/audit.

---

## 7. Repair E: article-wide coverage ledger

Add a persisted coverage model equivalent to:

```ts
type ContentRegionInspection = {
  regionId: string;
  heading: string | null;
  structuralType: string;
  startUnitId: string;
  endUnitId: string;
  unitCount: number;
  status:
    | "uninspected"
    | "sampled"
    | "inspected"
    | "excluded";
  sampledUnitIds: string[];
  candidateBearing:
    | "unknown"
    | "likely"
    | "unlikely";
  dispositionReason: string | null;
};
```

Use repository naming conventions but preserve the semantics.

Derive major regions deterministically from the complete source-block map.

`read_source_units` must update region coverage.

The model chooses:

- which regions to sample;
- which units to read;
- whether a sampled region requires deeper inspection;
- whether a region is likely claim-bearing;
- whether a region may be excluded;
- when coverage is sufficient.

The host enforces procedural coverage only. It does not decide semantic importance.

An exclusion requires a non-empty persisted reason.

---

## 8. Repair F: coverage-aware validation and finalization

Add a hard validation finding:

```text
UNINSPECTED_MAJOR_REGION
```

Finalization in complete mode must be blocked while any major region is:

- `uninspected`; or
- sampled but still marked `candidateBearing: unknown` without a justified disposition.

Do not make `THIN_PORTFOLIO` a hard error. A short article may legitimately yield fewer than five claims.

The hard gate is unexplained unseen content, not claim count.

The final artifact must show:

- all major regions;
- their coverage status;
- sampled unit IDs;
- disposition reasons;
- selected claims associated with regions where possible.

---

## 9. Narrow instruction change

Bump the manager instruction version once.

Add only language equivalent to:

```text
Before treating a package as complete, establish article-wide coverage.

Use the complete content map to identify every major structural region.
Inspect a representative portion of each region and inspect likely
claim-bearing regions more deeply. Do not infer the article's full thesis or
claim portfolio from its opening section.

Every major region must be inspected, sampled and dispositioned, or explicitly
excluded with a recorded reason before finalization. A locally coherent package
is not complete while substantial source regions remain unseen.
```

Do not rewrite unrelated semantic guidance.

---

## 10. Offline token projection

Before a live run, construct an offline/request-level projection using the actual filtered inputs and conditionally exposed schemas.

Produce a table for a representative eleven-turn run showing:

- manager instructions;
- terminal schema;
- tools exposed and schema tokens per turn;
- compact state payload;
- source text payload;
- package/claim payload;
- validation payload;
- projected input tokens per turn;
- projected cumulative input tokens.

Do not authorize a live run unless:

- projected cumulative input is <= 45,000;
- target projection is near or below 30,000;
- no later request grows without bound;
- no required grounding or validation data is silently lost;
- tool selection remains model-directed.

If projection remains above 45,000, stop and recommend a hybrid bounded-inventory plus agentic validation/repair architecture. Do not run F03.

---

## 11. Offline tests

Add tests proving:

### Context economy

- per-request usage is persisted;
- trace-export failure does not lose request usage;
- cumulative input budget stops the run;
- superseded package saves are removed from later model input;
- old source text is removed only under deterministic retention rules;
- exact source text can be reread;
- active findings remain visible;
- tool exposure varies by legal state;
- multiple legal actions remain available where appropriate;
- no host-selected fixed route exists;
- projected cumulative input stays within the gate.

### Coverage

- major regions are derived deterministically;
- reading units updates the correct regions;
- exclusions require reasons;
- uninspected regions produce a hard finding;
- finalization is blocked by uncovered regions;
- short fully covered content may finalize with fewer than five claims;
- terminal artifacts show coverage.

All prior tests must remain green.

---

## 12. One live F03 verification

Only after all offline gates pass, run F03 exactly once.

Do not run F02, F06, or F08.

Do not tune during or after the run in this milestone.

Compare with the original F03 run:

- model requests;
- per-request input/cached/uncached/output tokens;
- cumulative input tokens;
- tool schemas exposed per turn;
- regions sampled/inspected/excluded;
- unique source units inspected;
- last inspected unit;
- selected-claim count;
- dispositions;
- validation findings;
- finalization attempts;
- terminal status;
- latency;
- semantic defects still present.

The canonical package must be reloaded and hash-checked from MySQL.

---

## 13. Hard prohibitions

Do not:

- accept 10× token usage as an agency premium;
- run blind fixtures before this repair;
- increase turn/tool/token budgets;
- switch models;
- add a mandatory sequential full-article read;
- add model-generated lossy compaction;
- use server-managed continuation as an unmeasured magic fix;
- mix client history with `conversationId` or `previousResponseId`;
- add subagents or handoffs;
- tune attribution, atomicity, treatment, supplier, or claim wording;
- encode F03 answers;
- alter CF5;
- add routes or EvidenceRun;
- commit.

---

## 14. Acceptance criteria

Milestone 4C passes only if:

1. exact per-request usage is permanently retained;
2. cumulative input budget is enforced;
3. model-visible history is deterministically bounded;
4. durable audit history remains complete;
5. fixed tool-schema exposure is materially reduced;
6. tool choice remains genuinely model-directed;
7. major article regions are persisted and auditable;
8. finalization blocks on unexplained unseen regions;
9. projected F03 input is <= 45,000 before execution;
10. live F03 input is <= 45,000;
11. the repaired run reaches later article regions;
12. all prior tests remain green;
13. no unrelated semantic tuning occurs.

Target live input remains approximately 30,000 tokens. A result close to the 45,000 ceiling requires explicit justification and further optimization before broader evaluation.

---

## 15. Final report

Report:

1. exact files changed;
2. request-accounting design;
3. input-filter rules;
4. state-dependent tool exposure by state;
5. schema-token cost before and after;
6. tool-result payload cost before and after;
7. coverage-region model;
8. finalization gate;
9. exact instruction diff;
10. offline token projection;
11. all test results;
12. live F03 per-request usage;
13. original versus repaired total tokens;
14. original versus repaired article coverage;
15. final package and remaining semantic defects;
16. recommendation:
   - accept Milestone 4C and proceed to one blind fixture;
   - repair and rerun offline projection;
   - switch to hybrid bounded inventory plus agentic repair;
   - stop.

Then stop.
