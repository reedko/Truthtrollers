# Codex Execution Prompt — CF6 Milestone 2B
## Real MySQL Durability Verification

Work from the VeriStrata repository root.

Milestone 2’s offline implementation has passed:

- agent typecheck;
- 11/11 ClaimFoundry tool tests;
- 16/16 relevant ArticleDocument/storage tests;
- 26/26 CF5 regression tests;
- `git diff --check`;
- no model calls, manager agent, route, feature flag, EvidenceRun, CF5 change, or second framework.

The only unresolved Milestone 2 acceptance item is empirical verification of the migration and transactional persistence adapter against a disposable MySQL database.

## Objective

Verify, against a disposable configured MySQL database, that the implemented CF6 ClaimFoundry persistence layer actually provides:

- durable run-state persistence;
- append-only consequential tool events;
- immutable final packages;
- transaction safety;
- idempotency;
- legal event sequencing;
- trigger enforcement;
- rollback/cleanup behavior.

This is a verification-and-repair task only.

Do not begin Milestone 3.

## Governing records

Use:

1. `CF6_REAL_AGENT_BUILD_MCT_2026-07-27.docx`
2. `backend/agents/CF6_INTEGRATION_MAP.md`
3. `CF6_OUTPUT_CONTRACT_AND_ACCEPTANCE_DECISIONS.md`
4. `CF6_ACCEPTANCE_RUBRIC.md`
5. `CF6_FAILURE_CORPUS_MANIFEST.md`
6. the completed Milestone 1 and Milestone 2 implementations and reports

The actual repository code governs exact paths and names.

## Preflight

Before changing anything:

```bash
git status --short
git branch --show-current
git diff --stat
node --version
npm --version
cd backend && npm run typecheck:agents
cd backend && npm run test:agents:claim-foundry-tools
node --test backend/experiments/cf5/*.test.js
```

Inspect:

- the CF6 migration;
- CF6 run-state, tool-event, and final-package adapters;
- existing database test helpers and environment conventions;
- transaction and migration utilities;
- trigger definitions;
- rollback order and foreign-key dependencies.

Do not clean, stash, reset, switch branches, or commit.

## Database requirement

Use only a disposable MySQL database or disposable schema.

Do not run this migration against production or any shared persistent environment.

If no disposable MySQL target is available:

- do not fake the verification;
- stop;
- report the exact required environment variables;
- provide the exact commands the user must run;
- leave Milestone 2B blocked.

## Required verification

### 1. Migration application

Apply the CF6 migration to an empty disposable database.

Verify:

- all expected tables, indexes, constraints, foreign keys, and triggers exist;
- migration application succeeds cleanly;
- applying it a second time either fails clearly by design or is safely idempotent, according to repository migration conventions;
- no unrelated schema is changed.

### 2. Durable run-state recovery

Create a ClaimFoundry run state through the real MySQL adapter.

Then:

- dispose the adapter/process context;
- create a fresh adapter/process context;
- reload the state;
- prove all persisted fields survive exactly;
- prove state version, hashes, counters, statuses, timestamps, and content authorization remain intact.

Do not use the in-memory adapter for this test.

### 3. Append-only tool events

Persist multiple consequential tool events through the real adapter.

Verify:

- event sequence is monotonic and unique per run;
- event arguments/results or hashes survive reload;
- before/after state hashes survive reload;
- idempotent replay does not create a duplicate event;
- duplicate idempotency keys are handled exactly as designed;
- direct `UPDATE` of an event is blocked by the database trigger;
- direct `DELETE` of an event is blocked by the database trigger.

Capture the exact MySQL error returned by each trigger.

### 4. Immutable final packages

Finalize one structurally valid package through the real adapter.

Verify:

- the immutable final snapshot and canonical hash survive reload;
- repeated idempotent finalization returns the same package identity;
- direct `UPDATE` of the final package is blocked;
- direct `DELETE` of the final package is blocked;
- terminal state prevents further tool mutation.

Capture the exact MySQL errors produced by trigger enforcement.

### 5. Transaction rollback

Force a failure after at least one write inside a transaction.

Verify that the transaction leaves no partial combination such as:

- event without matching state update;
- state update without event;
- final package without terminal state;
- terminal state without final package.

Test the actual adapter’s transaction boundary, not a mocked transaction.

### 6. Concurrency and sequencing

Run a small bounded concurrency test against one run.

Verify:

- two competing writes cannot allocate the same event sequence;
- state version or locking prevents lost updates;
- idempotent duplicate requests converge to one durable mutation;
- any conflict is classified clearly and does not corrupt state.

Do not build a load-testing framework.

### 7. Rollback and cleanup

The implementation reports that rollback requires dropping:

1. final-package objects;
2. tool-event objects;
3. run-state objects.

Verify the exact dependency order from the migration.

Provide a safe disposable-database rollback procedure.

Do not weaken immutability triggers merely to make rollback easier. Administrative migration rollback may drop the schema objects in dependency order.

## Repair boundaries

If a real MySQL defect is found, make only the smallest repair required in:

- the CF6 migration;
- the CF6 persistence adapter;
- database-specific tests;
- narrowly related documentation or scripts.

Do not change:

- the semantic-core schema;
- tool contracts unless the database proves the contract impossible;
- validation semantics;
- patch policy;
- ClaimFoundry agent runtime;
- CF5;
- production routes.

Re-run the full Milestone 2 offline suite after any repair.

## Required tests/scripts

Add or use a dedicated integration command such as:

```bash
cd backend
npm run test:agents:claim-foundry-mysql
```

The command must:

- require an explicit disposable-test database configuration;
- refuse to run when pointed at a non-test database according to a clear safety check;
- apply or verify the migration;
- exercise the real transactional adapter;
- clean up only the disposable test data/schema it created;
- make no model/API calls.

Document exact required environment variables in `backend/agents/README.md`.

## Final verification

Run:

```bash
cd backend
npm run typecheck:agents
npm run test:agents:claim-foundry-tools
npm run test:agents:claim-foundry-mysql
node --test backend/experiments/cf5/*.test.js
git diff --check
```

Also rerun the relevant ArticleDocument/storage tests.

## Acceptance

Milestone 2B passes only if:

1. the migration applies successfully to disposable MySQL;
2. state survives adapter/process recreation;
3. tool events are durably append-only;
4. final packages are durably immutable;
5. trigger enforcement is demonstrated with real MySQL errors;
6. transaction rollback prevents partial persistence;
7. concurrency does not duplicate sequence numbers or lose updates;
8. idempotency works against the database, not only in memory;
9. rollback/cleanup order is verified;
10. all prior Milestone 2 and CF5 tests remain green;
11. no Milestone 3 code is added.

## Final report

Report:

1. disposable database configuration used, excluding secrets;
2. migration command and result;
3. exact schema objects created;
4. exact tests run and results;
5. state-recovery evidence;
6. append-only trigger evidence;
7. final-package immutability evidence;
8. transaction rollback evidence;
9. concurrency/idempotency evidence;
10. rollback order and cleanup result;
11. exact files changed;
12. all regression results;
13. recommendation:
   - accept Milestone 2 and proceed to Milestone 3;
   - repair and rerun Milestone 2B;
   - stop.

Then stop. Do not begin Milestone 3.
