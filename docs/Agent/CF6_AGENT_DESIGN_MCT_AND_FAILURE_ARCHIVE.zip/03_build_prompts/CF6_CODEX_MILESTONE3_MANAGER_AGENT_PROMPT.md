# Codex Execution Prompt — CF6 Milestone 3
## ClaimFoundry Manager Agent Vertical Slice

Work from the VeriStrata repository root.

Milestones 1 and 2 are accepted. Milestone 1 proved a real OpenAI Agents SDK-managed model/tool loop. Milestone 2 proved the persisted CF6 semantic-core state, append-only tool events, immutable final packages, bounded domain tools, idempotency, legal transitions, abstention, patch safety, and real MySQL durability.

This milestone gives one ClaimFoundry manager agent control of those tools.

## 1. Governing hierarchy

Use, in order:

1. `CF6_REAL_AGENT_BUILD_MCT_2026-07-27.docx`
2. `backend/agents/CF6_INTEGRATION_MAP.md`
3. `CF6_OUTPUT_CONTRACT_AND_ACCEPTANCE_DECISIONS.md`
4. `CF6_ACCEPTANCE_RUBRIC.md`
5. `CF6_FAILURE_CORPUS_MANIFEST.md`
6. `TM5_ClaimFoundry_Brain_First_Spec.md`
7. `CF1_CLAIM_PACKAGE_V1_COMPLETE_REFERENCE.md`
8. the accepted Milestone 1 and Milestone 2 code and reports

When they conflict:

- the CF6 MCT governs runtime architecture and milestone order;
- the Integration Map governs repository-specific facts;
- the output-contract decisions govern the CF6 semantic core;
- the acceptance rubric governs eventual promotion, not this first vertical-slice pass;
- the failure corpus supplies test cases and historical cautions;
- TM5 stages are available semantic capabilities and persisted artifacts, not a mandatory hard-coded sequence;
- the legacy CF1 package is compatibility evidence, not the semantic design;
- accepted Milestone 1 and 2 code governs actual runtime and tool APIs.

Do not silently resolve a conflict. Report it with repository evidence.

## 2. Objective

Implement one real ClaimFoundry manager agent and a bounded vertical-slice runner.

The model must choose among the seven accepted ClaimFoundry tools based on current persisted state, content inspected, working package, validation findings, repair history, and remaining budgets.

The application must not prescribe a fixed:

```text
inspect -> draft -> validate -> repair -> finalize
```

sequence.

A run may follow that route, but the model chooses each next permitted action. It may inspect different regions, search locally, save a package, validate, reread, patch, revalidate, finalize, abstain, or stop at review/budget boundaries.

This milestone proves the domain agent loop on one fixture before broad evaluation.

## 3. Do not build yet

Do not implement:

- EvidenceRun;
- product routes;
- production feature flags;
- queue/worker integration;
- human-review UI;
- subagents;
- handoffs;
- planner agents;
- new memory layers;
- portfolio-scale blind evaluation;
- prompt tuning from fixture output;
- acceptance-rubric promotion;
- automatic legacy-package projection;
- CF5 changes;
- commits.

## 4. Mandatory preflight

Before editing:

```bash
git status --short
git branch --show-current
git diff --stat
node --version
npm --version

cd backend
npm run typecheck:agents
npm run test:agents:claim-foundry-tools
npm run test:agents:claim-foundry-mysql
node --test experiments/cf5/*.test.js
```

Inspect all accepted Milestone 1 shared-runtime files, all accepted Milestone 2 ClaimFoundry files, the actual installed Agents SDK types, the smoke-agent SDK pattern, fixture loading, ArticleDocument construction, tracing/usage normalization, and artifact conventions.

Confirm:

- no production route imports `backend/agents/`;
- all seven domain tools are model-free;
- MySQL integration is green;
- CF5 remains isolated;
- dirty files are preserved.

Do not clean, stash, reset, switch branches, overwrite old artifacts, or commit.

Stop and report if accepted Milestone 2 facts are not reproducible.

## 5. Required agent

Create one manager agent named `ClaimFoundry`.

No subagents. No handoffs.

The agent receives run ID, content ID, instruction version, budget profile, and typed local context giving access only to the accepted ClaimFoundry tools and authorized run state.

Do not dump article text into system/developer instructions or the initial user message.

The initial user message should be minimal, for example:

> Build and finalize the ClaimFoundry package for content `<contentId>` under run `<runId>`.

The agent must inspect content through tools.

## 6. Governing instruction

Implement a versioned instruction closely aligned with:

```text
You are the ClaimFoundry agent.

Your goal is to produce the smallest complete, grounded set of independently
investigable evidentiary targets needed to evaluate the substantive
representations made or relied upon by the supplied content and to support
later retrieval of evidence bearing directly on each target.

The content may be an article, post, transcript, video transcript, paper,
speech, thread, report, or other normalized content. Do not assume journalism
or a simple pro/con argument structure.

Use only the supplied content. Do not search for outside evidence. Do not
decide whether a representation is true.

You control extraction through the available ClaimFoundry tools. Inspect the
content as needed, maintain a working semantic-core package, validate it,
repair material defects through bounded patch operations, and finalize only
when ready or when typed abstention or review is required.

A useful selected target:
- is grounded in valid source units;
- is independently investigable outside the content;
- expresses one coherent evidentiary question;
- preserves material names, quantities, dates, polarity, scope,
  qualification, attribution, and article treatment;
- materially affects evaluation of the content;
- is not decorative, procedural, incidental, or redundant.

Default to the deepest independently verifiable substantive proposition.
Preserve surface reporting, reporting voice, attribution layers, and content
supplier separately.

For “X said/revealed/claimed P,” P is normally the verification target.
Create a separate attribution/provenance target only when the content
materially concerns whether X made the statement, X's statement history,
credibility, authorship, disclosure, existence, or identity.

Do not guess unresolved suppliers. Record unknown where necessary.

Do not follow a fixed ritual. Choose the next tool based on content, persisted
state, current package, validation findings, repair history, and budget.

Never invent grounding, quotations, studies, identifiers, suppliers, source
units, or content not present in the authorized source.

Validation does not silently mutate. Repair only through the bounded patch
tool. Semantic-risk patches may require human review.

Respect all budgets. Finalize only after structural gates pass and no review
is pending. Otherwise stop with typed abstention, review, budget, or failure.
```

Do not add fixture-specific language or old prompt debris. Do not tune this instruction during the first live run.

## 7. Terminal output

Use a strict repository-owned completion schema such as:

```ts
type ClaimFoundryAgentCompletion = {
  runId: string;
  contentId: string;
  terminalStatus:
    | "completed"
    | "abstained"
    | "awaiting_review"
    | "budget_exhausted"
    | "failed";
  finalPackageId: string | null;
  finalPackageHash: string | null;
  abstentionReason: string | null;
  reviewReasons: string[];
  summary: string;
};
```

The persisted finalized package remains canonical.

Do not let the model bypass `finalize_claim_package` by returning an unpersisted package.

A completed output is valid only if persisted state contains an immutable finalized package. Abstained/review outputs must match persisted state.

## 8. Runtime and runner

Implement:

- `claimFoundryInstructions.ts`
- `claimFoundryAgent.ts`
- `claimFoundryRunner.ts`
- any narrowly necessary terminal-output schema/context adapter

Requirements:

- SDK-managed multi-turn tool loop;
- no manual model/tool/model choreography;
- accepted seven tools only;
- dynamic identifiers/version metadata, but no article text in instructions;
- structured terminal output;
- persisted state after consequential calls;
- tracing and normalized usage;
- clear terminal classification;
- no provider import outside the shared runtime boundary;
- no direct database access from the agent definition;
- no generic tools.

Use the installed SDK API and types.

## 9. Budgets

Use initial defaults unless accepted names differ:

- max model turns: 12;
- max tool calls: 30;
- max repair rounds: 2;
- max one repair per finding;
- accepted token limits;
- explicit wall-clock timeout.

Reconcile SDK usage with persisted counters.

Stop clearly on turn, tool, token, wall-time, repair, review, abstention, or infrastructure boundaries.

Do not force output to avoid abstention.

## 10. Tool-trajectory proof

Persist and report, in order:

- model turn;
- tool selected;
- validated arguments or hash;
- result or hash;
- state before/after;
- duration;
- validation findings;
- terminal decision.

Distinguish model decisions, deterministic enforcement, and infrastructure events.

Reject the run as non-agentic if application code selected the full sequence.

## 11. First fixture

Run one live fixture.

Default to `CF1-F03` unless repository constraints make another accepted fixture materially safer.

F03 is preferred because it exercises attribution/substance separation, challenged claims, polarity, source/treatment independence, and reporting-frame failures.

Do not embed F03 answers, tune after the first result, claim rubric success from one run, or add fixture-specific code.

Allow a fixture argument so F02 or F06 can run without code changes.

## 12. Vertical-slice runner

Add a non-production command that:

1. loads one fixture through ArticleDocument;
2. creates a persisted CF6 run with explicit versions/budgets/model;
3. invokes the manager agent through the accepted SDK runtime;
4. waits for terminal status;
5. reloads persisted state and final package;
6. writes a timestamped CF6 artifact directory.

Suggested root:

```text
artifacts/claim-foundry/cf6-agent/<fixture>-<timestamp>/
```

Write at least:

```text
run-config.json
source-manifest.json
instruction.txt
tool-schema-summary.json
tool-trajectory.json
validation-reports.json
repair-history.json
terminal-output.json
final-package.json
abstention.json
usage.json
latency.json
trace.json
run-manifest.json
review.html or review.md
```

Write only files applicable to the terminal outcome. Do not store secrets.

## 13. Review report

Show:

- fixture/source identity;
- terminal status;
- selected claim rows;
- surface statement;
- substantive assertion;
- supplier;
- article treatment;
- verification target;
- substantive grounding;
- exclusions/abstentions;
- validation history;
- repairs;
- full trajectory;
- model calls;
- tool calls;
- turns;
- tokens;
- wall time;
- trace ID;
- terminal cause.

This is not the full twelve-dimension acceptance report.

Reuse an existing builder only if it preserves CF6 fields.

## 14. Tests

Add non-billable tests for:

- instructions include identifiers but not article text;
- only seven accepted tools are exposed;
- terminal schema;
- completion requires persisted finalization;
- abstention/review outputs match persisted state;
- budget/terminal normalization;
- runner does not manually prescribe tool order;
- agent definition does not import CF5, routes, EvidenceRun, shell, filesystem, SQL, Redis, or web tools;
- final package is loaded from persistence, not trusted from model text.

Add one explicit live/billable command separate from ordinary tests.

Suggested scripts:

```json
{
  "test:agents:claim-foundry-agent": "...offline tests...",
  "run:agents:claim-foundry-fixture": "...live runner..."
}
```

## 15. Verification

Run:

```bash
cd backend
npm run typecheck:agents
npm run test:agents:claim-foundry-tools
npm run test:agents:claim-foundry-mysql
npm run test:agents:claim-foundry-agent
node --test experiments/cf5/*.test.js
```

Run relevant ArticleDocument/storage tests.

Then, with explicit disposable MySQL and API/model configuration:

```bash
cd backend
npm run run:agents:claim-foundry-fixture -- --fixture CF1-F03
```

If credentials/database are unavailable, do not fake a pass. Complete offline tests and report the live item as blocked.

## 16. Hard prohibitions

Do not:

- hard-code the tool sequence;
- create a scripted Call 1/Call 2/repair pipeline;
- dump article text into instructions;
- search external evidence;
- mutate canonical target text downstream;
- let the model write files or SQL;
- expose shell, filesystem, web, database, Redis, or repository tools;
- add subagents/handoffs;
- tune against F03 after the first run;
- silently repair semantics;
- bypass persisted validation/finalization;
- claim full CF6 acceptance;
- alter CF5;
- add production integration;
- commit.

## 17. Acceptance

Milestone 3 passes only if:

1. one ClaimFoundry manager agent exists;
2. the SDK manages repeated model/tool turns;
3. the model selects among the seven tools;
4. the runner does not prescribe the full sequence;
5. content is inspected only through authorized tools;
6. state/events persist;
7. validation feedback returns to the model;
8. repairs use bounded patches only;
9. structural errors/review block finalization;
10. completion references an immutable persisted package;
11. abstention/review/budget/failure are typed;
12. the trajectory is inspectable;
13. all prior tests remain green;
14. no EvidenceRun, route, feature flag, subagent, or production default is added;
15. no fixture-specific answer is encoded.

A poor first semantic result may still prove the vertical slice mechanically, but must be reported honestly.

## 18. Final report

Report:

1. preflight;
2. files created/modified;
3. instruction version;
4. tools exposed;
5. proof the SDK owns the loop;
6. terminal contract;
7. budgets/stopping;
8. offline tests;
9. live configuration;
10. complete trajectory;
11. final package or typed terminal result;
12. validation/repair history;
13. model calls, tool calls, turns, tokens, latency, trace ID;
14. CF5/prior regressions;
15. semantic defects observed;
16. deviations from governing records;
17. recommendation: accept and proceed to blind fixture evaluation, repair/rerun, or stop.

Then stop. Do not begin multi-fixture evaluation or EvidenceRun.
