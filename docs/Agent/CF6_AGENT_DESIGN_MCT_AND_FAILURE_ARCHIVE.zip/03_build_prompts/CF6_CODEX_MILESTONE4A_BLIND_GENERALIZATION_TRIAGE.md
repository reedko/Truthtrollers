# Codex Execution Prompt — CF6 Milestone 4A
## Untouched Blind Generalization Triage

Work from the VeriStrata repository root.

Milestone 3 is accepted as a **mechanical vertical-slice proof**, not as a semantic success.

The first F03 run proved:

- one real SDK-managed ClaimFoundry manager agent controlled the seven accepted tools;
- state, events, validation, finalization, MySQL durability, and package-hash verification worked;
- the final package was reloaded from MySQL rather than trusted from model output.

The same run was semantically thin:

- only three claims;
- inspection stopped near the beginning of a 404-unit article;
- material later assertions were omitted;
- no dispositions explained the omissions;
- attribution/supplier and atomicity defects remained;
- the agent finalized immediately after a `THIN_PORTFOLIO` warning;
- deterministic validation did not evaluate material omission, treatment correctness, semantic grounding, attribution correctness, polarity, or verdictability.

Do not tune or rerun F03 in this milestone.

## 1. Objective

Run the exact accepted Milestone 3 agent, instruction version, tool schemas, validators, budgets, and model configuration on genuinely blind fixtures to determine whether the F03 failures generalize.

Run one untouched live pass on:

1. `CF1-F02`
2. `CF1-F06`
3. `CF1-F08`

These fixtures test different pressures:

- F02: contradictions, qualification, and challenged treatment;
- F06: causal mechanisms and crux retention;
- F08: short factual content and underfill behavior.

This is triage, not prompt tuning and not full acceptance testing.

## 2. Freeze all semantic variables

Use exactly the accepted Milestone 3 configuration unless a fixture cannot run for a purely mechanical reason:

- instruction version: `cf6.claim-foundry.manager.v1`
- tool schema version: `cf6.tools.v1`
- model: `gpt-4.1-mini`
- same model settings;
- same runtime budgets;
- same persisted budgets;
- same semantic-core schema;
- same tool descriptions;
- same validators;
- same patch policy;
- same terminal contract.

Do not alter wording, tool descriptions, schemas, validators, budgets, model, or fixture content between runs.

If a mechanical bug blocks a run, stop and report it before changing code. Do not disguise a semantic change as a bug fix.

## 3. Blindness rules

Before all three runs finish:

- do not inspect sealed gold keys;
- do not compare outputs with expected claims;
- do not edit prompts;
- do not rerun a fixture;
- do not add fixture-specific code;
- do not modify source normalization;
- do not change the model or budgets;
- do not manually steer the agent.

Run the fixtures in a recorded order chosen before execution.

## 4. Mandatory preflight

Run:

```bash
git status --short
git branch --show-current
git diff --stat
node --version
npm --version

cd backend
npm run typecheck:agents
npm run test:agents:claim-foundry-agent
npm run test:agents:claim-foundry-tools
npm run test:agents:claim-foundry-mysql
node --test experiments/cf5/*.test.js
```

Run the relevant ArticleDocument/source/storage tests.

Confirm:

- accepted Milestone 3 code is unchanged;
- no production route imports CF6;
- no prompt/tool/schema version changed;
- MySQL test database is disposable;
- API/model configuration is explicit;
- all pre-existing dirty work is preserved.

Do not clean, stash, reset, switch branches, or commit.

## 5. Run commands

Use the accepted live runner, for example:

```bash
cd backend
npm run run:agents:claim-foundry-fixture -- --fixture CF1-F02
npm run run:agents:claim-foundry-fixture -- --fixture CF1-F06
npm run run:agents:claim-foundry-fixture -- --fixture CF1-F08
```

Do not rerun a completed fixture in this milestone.

If a run ends in typed failure, abstention, review, or budget exhaustion, preserve that result. Do not retry merely to obtain completion.

## 6. Required per-run artifacts

Preserve the full accepted Milestone 3 artifact set for each fixture, including:

- run configuration;
- source manifest;
- exact instruction;
- tool schema summary;
- full tool trajectory;
- validation reports;
- repair history;
- terminal output;
- final package or abstention record;
- usage;
- latency;
- trace metadata;
- run manifest;
- human-readable review.

The canonical package must be reloaded and hash-checked from MySQL.

Never trust model-returned package IDs, hashes, or semantic content without persisted-state verification.

## 7. Add deterministic inspection metrics

Without making semantic judgments, compute for each run:

- total source-unit count;
- unique units inspected;
- percentage of units inspected;
- first and last inspected unit positions;
- largest uninspected contiguous region;
- number of content-map calls;
- number of read calls;
- number of search calls;
- number of package saves;
- number of validation calls;
- number of patches;
- number of finalization attempts;
- selected-claim count;
- disposition count;
- unknown-supplier count;
- thin-portfolio warning present;
- whether validation was followed by further inspection;
- whether `THIN_PORTFOLIO` was followed immediately by finalization;
- model turns;
- tool calls;
- tokens;
- wall time;
- terminal status.

Do not label these metrics as semantic quality scores.

## 8. Post-run semantic review

Only after all three untouched runs are complete may the evaluator open the governing fixture expectations and failure-corpus records.

Produce a separate review for each fixture covering:

- central/crux assertions recovered;
- material omissions;
- independent verdictability;
- compound claims;
- surface/substance separation;
- supplier correctness;
- article treatment;
- polarity;
- semantic grounding adequacy;
- portfolio economy;
- dispositions for omitted or rejected material;
- premature finalization;
- whether later article regions were adequately inspected.

Do not alter the run artifacts after review.

## 9. Cross-fixture diagnosis

Classify recurring failures by their earliest observable cause.

Use categories such as:

- incomplete source inspection;
- weak content-map interpretation;
- failure to search;
- premature package drafting;
- premature finalization;
- thin-portfolio warning ignored;
- missing disposition accounting;
- attribution/source confusion;
- surface/substance fusion;
- compound verification target;
- challenged-treatment loss;
- polarity error;
- semantic-grounding error;
- validator blind spot;
- diagnostic too weak to guide further action;
- budget exhaustion;
- tool friction;
- model-capability limitation.

For each recurring defect, identify the first trajectory event where a better choice could have prevented it.

Do not propose a giant prompt rewrite.

## 10. Decision rule

After the three runs, recommend one of:

### A. Proceed to focused prompt/tool tuning

Choose this only if:

- the agent loop remains mechanically sound;
- failures recur in one or two identifiable decision classes;
- the earliest bad decision can plausibly be influenced by a small instruction, tool-description, diagnostic, or stopping-rule change.

Name no more than two failure classes for the first tuning experiment.

### B. Repair architecture before tuning

Choose this if:

- the agent cannot practically inspect long content within the action/budget design;
- tool outputs prevent adequate global coverage;
- the content map is insufficient;
- state/trajectory data cannot explain omissions;
- validation cannot signal when inspection is materially incomplete.

### C. Stop or change model

Choose this if:

- the same model repeatedly fails to use the available tools despite clear instructions;
- outputs are unusably thin or compound across distinct fixtures;
- token cost is grossly disproportionate to semantic value;
- small prompt/tool changes are unlikely to address the root problem.

## 11. Hard prohibitions

Do not:

- tune against F03;
- edit the manager instruction;
- edit tool descriptions;
- add a coverage validator;
- add a mandatory traversal loop;
- increase budgets;
- switch models;
- rerun a fixture;
- inspect gold before all runs complete;
- encode expected claims;
- alter CF5;
- add routes, EvidenceRun, subagents, or handoffs;
- commit.

This milestone observes the untouched agent. It does not improve it.

## 12. Final report

Report:

1. preflight and version freeze;
2. exact run order;
3. exact configuration used;
4. test results;
5. per-fixture terminal result;
6. per-fixture deterministic inspection metrics;
7. per-fixture semantic review;
8. cross-fixture recurring failure classes;
9. earliest bad trajectory decision for each recurring class;
10. token and latency totals;
11. whether the F03 thin-inspection pattern generalized;
12. no more than two recommended tuning targets;
13. recommendation A, B, or C;
14. exact files changed, which should be limited to new artifacts, evaluation output, and narrowly necessary runner/reporting code.

Then stop.

Do not tune, rerun, or begin EvidenceRun.
