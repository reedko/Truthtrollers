# CF6 Codex Prompt — Milestone 2: Persisted State and Domain Tools

Work from the VeriStrata repository root.

## Governing records

Use, in order:

1. `CF6_REAL_AGENT_BUILD_MCT_2026-07-27.docx`
2. `backend/agents/CF6_INTEGRATION_MAP.md`
3. `CF6_OUTPUT_CONTRACT_AND_ACCEPTANCE_DECISIONS.md`
4. `CF6_ACCEPTANCE_RUBRIC.md`
5. `CF6_FAILURE_CORPUS_MANIFEST.md`
6. `TM5_ClaimFoundry_Brain_First_Spec.md`
7. `CF1_CLAIM_PACKAGE_V1_COMPLETE_REFERENCE.md`

Milestone 1 has passed. Treat its actual `backend/agents/` implementation and installed versions as current code truth. Do not redesign it without a demonstrated defect.

## Objective

Implement only the persisted ClaimFoundry state and bounded domain-tool layer that the future manager agent will control.

Build:

- durable `ClaimFoundryRunState`;
- append-only consequential tool events;
- strict budgets and legal state transitions;
- a versioned CF6 semantic-core working-package schema;
- seven tools:
  - `get_content_map`
  - `read_source_units`
  - `find_source_units`
  - `save_working_package`
  - `validate_working_package`
  - `apply_package_patch`
  - `finalize_claim_package`
- non-billable unit/integration tests.

Do not build the ClaimFoundry agent, instructions, runner, EvidenceRun, product routes, feature flags, subagents, or handoffs.

## Preflight

Before editing:

```bash
git status --short
git branch --show-current
git diff --stat
node --version
npm --version
cd backend && npm run typecheck:agents
node --test backend/experiments/cf5/*.test.js
```

Inspect the Milestone 1 code, ArticleDocument/source-unit APIs, existing run/package stores, transaction/idempotency helpers, migration conventions, and CF5 validators.

Preserve the dirty worktree. Do not clean, stash, reset, switch branches, overwrite artifacts, or commit.

Stop and report if repository facts materially differ from the Integration Map or the Milestone 1 report.

## CF6 semantic-core contract

Do not use CF5’s five-field row as the canonical schema. Do not copy `cf1.claimPackage.v1` wholesale.

Product definition:

> The smallest complete set of grounded, independently investigable substantive representations needed to evaluate the content and find evidence bearing directly on the content.

The package must include version/run/content identity, source/content hashes, status, selected claims, explicit exclusions/abstentions/merges/deferred items, validation reports, and audit metadata.

Every selected claim must include:

- stable claim ID;
- `surfaceStatement`;
- `substantiveAssertion`;
- `attributionLayers[]`;
- `contentSupplier`;
- `contentSupplierKind`;
- `reportingVoice`;
- `articleTreatment`;
- `polarity`;
- `scope`;
- `attributionUnitIds[]`;
- `substantiveGroundingUnitIds[]`;
- `verificationTarget`;
- `themeIds[]`;
- `materiality`;
- `selectionRationale`;
- `identityHints`.

Default verification target: the deepest independently verifiable substantive proposition. Preserve the surface reporting event separately. Create a separate attribution/provenance target only when the article materially concerns whether the source made the statement, the source’s statement history, credibility, authorship, disclosure, existence, or identity.

Expose at most three attribution layers. Beyond the cap, require review or typed abstention. Record unresolved suppliers as `unknown`; never guess.

Portfolio rules: ceiling 15, no hard floor, flag below 5, never pad.

Define, but do not execute, the evidence-ready projection:

- `targetId`
- `canonicalTargetText`
- `verificationTarget`
- `scopeAndQualifiers`
- `contentSupplier`
- `identityHints`
- `mustMatch`
- `usefulSourceRoles`
- `rejectionBoundaries`
- `groundingReferences`

No downstream component may mutate canonical target text.

## Persisted run state

Implement a versioned state containing at least:

- run ID and content ID;
- source-unit manifest hash;
- status:
  - `created`
  - `inspecting`
  - `drafting`
  - `validating`
  - `repairing`
  - `awaiting_review`
  - `completed`
  - `abstained`
  - `failed`
- configured budgets and actual counters;
- inspected unit IDs;
- grounded semantic notes;
- working package;
- validation reports;
- repair history;
- pending-review reasons;
- final package ID;
- trace ID;
- instruction/tool-schema/model/code versions;
- timestamps.

Persist after every consequential tool call. Conversation history is not domain state.

Use existing MySQL/storage/transaction/idempotency infrastructure where appropriate. Add the smallest additive migration required for durable state and append-only events. Do not use Redis as the sole store.

Each mutating event must capture run ID, monotonic sequence, tool name/schema version, validated arguments or hash, result or hash, before/after state hashes, duration, status/error, idempotency key, and timestamp.

## Tool requirements

All tools must use strict Zod input/output schemas, typed local context, authorization to the current content, budget checks, normalized errors, persistence, and idempotency where mutating. No tool may call a model.

### `get_content_map`

Wrap existing ArticleDocument/source-block functions. Return bounded headings, structural block ranges/types, speaker/citation/reference signals, and source-unit IDs. Read-only. No semantic extraction.

### `read_source_units`

Read only requested valid units from the authorized content, optionally with bounded adjacent context. Preserve order, enforce count/text limits, reject foreign or nonexistent IDs, and persist inspected IDs.

### `find_source_units`

Deterministic local search only. Support bounded literal/normalized token matching for phrases, entities, citations, and identifiers. Return real computed matches and unit metadata. No web or model search.

### `save_working_package`

Create or replace the current structurally valid CF6 package. Reject invalid/foreign source IDs, duplicate claim IDs, unauthorized content, malformed attribution/substantive grounding, and more than 15 selected claims. Do not silently rewrite semantic text. Persist before/after hashes and idempotency data.

### `validate_working_package`

Return typed findings and never mutate.

Deterministically enforce:

- all source IDs exist and belong to this content;
- offsets/spans and cross-references are valid;
- attribution and substantive grounding are separately well formed;
- no fabricated/foreign grounding;
- identifier and schema integrity.

Represent semantic checks honestly. The tool must not pretend deterministic code proves:

- semantic grounding adequacy;
- atomicity;
- material omission;
- treatment correctness;
- attribution correctness;
- polarity;
- verdictability.

Provide typed findings and a coverage matrix showing deterministic, heuristic, unavailable, or later-semantic-review checks. Wrap existing validators only where contracts truly fit.

Use failure codes where useful, including invalid grounding, compound unit, duplicate, ambiguous reference, provenance conflation, treatment conflict, source loss, reporting-frame fusion, polarity flip, challenged dropped, over-selection, under-selection, and schema error.

### `apply_package_patch`

Use a strict discriminated union, not generic arbitrary JSON patching.

Allowed verbs:

- add
- remove
- replace
- split
- merge
- change treatment
- change provenance
- resolve reference
- change scope
- change polarity

Require explicit target IDs, reason, related finding IDs, grounding for changed semantic content, before/after hashes, and idempotency key. Always rerun structural validation. Preserve full history.

Any patch that may change substance, polarity, source, treatment, or scope must transition to `awaiting_review` unless content preservation is provable by an allow-listed deterministic rule.

Maximum one repair per defect and two repair rounds per run. No fixture-specific wording or source hacks.

### `finalize_claim_package`

Block when:

- no working package exists;
- structural hard errors remain;
- human review is pending;
- budgets/repair accounting are inconsistent.

Support typed abstention with explicit reason and inspected context.

Persist an immutable final package/hash and terminal event idempotently.

Distinguish run finalization from CF6 product promotion. Finalization does not mean the acceptance rubric passed.

## State transitions

Implement and test a legal transition table. Do not hard-code a compulsory workflow.

Typical legal path:

```text
created
  -> inspecting
  -> drafting
  -> validating
  -> repairing
  -> validating
  -> awaiting_review
  -> completed | abstained | failed
```

The future agent chooses the next permitted tool. The tool layer only enforces boundaries and invariants.

## Tests

Add dedicated non-billable tests covering:

- tool schema validation;
- authorization and invalid source IDs;
- deterministic ordering and result caps;
- state persistence and recovery;
- event sequencing;
- idempotent replay;
- package size/claim ceiling;
- non-mutating validation;
- honest semantic coverage reporting;
- every patch operation;
- forbidden mutation;
- no mutation after failed patch;
- repair limits;
- review-required transitions;
- blocked finalization;
- typed abstention;
- immutable final package;
- illegal state transitions.

Use only the smallest relevant validator/repair examples from `CF6_FAILURE_CORPUS_MANIFEST.md`. Do not normalize or rerun the entire historical archive.

## Expected organization

Prefer:

```text
backend/agents/claimFoundry/
  claimFoundryContext.ts
  claimFoundryState.ts
  claimFoundrySchemas.ts
  claimFoundryTools.ts
  claimFoundryPersistence.ts
  claimFoundryValidation.ts
  claimFoundryPatch.ts
  claimFoundryErrors.ts

backend/agents/tests/claimFoundry/
  state.test.ts
  persistence.test.ts
  contentTools.test.ts
  packageTools.test.ts
  patch.test.ts
  finalization.test.ts
```

Follow repository conventions if a different exact split is cleaner. Explain any extra files.

Expected additional changes may include additive migration files, package test scripts, and narrowly required exports from existing ArticleDocument/storage modules.

## Hard prohibitions

Do not:

- implement the manager agent, instructions, or runner;
- call a model from a domain tool;
- add EvidenceRun;
- add routes, feature flags, queues, subagents, handoffs, or memory layers;
- modify CF5;
- expose shell, filesystem, generic SQL, Redis, web, repository, or arbitrary write tools;
- silently repair semantics;
- claim deterministic proof of entailment;
- flatten CF6 into CF5 or the legacy package;
- treat finalized as accepted;
- commit.

## Verification commands

Add a dedicated script such as:

```bash
cd backend
npm run typecheck:agents
npm run test:agents:claim-foundry-tools
```

Also run:

```bash
node --test backend/experiments/cf5/*.test.js
```

Run relevant existing ArticleDocument and storage tests.

If database integration requires configured MySQL, provide a fully runnable offline/unit subset plus an explicit integration command and environment requirements. Do not fake persistence success.

## Acceptance

Milestone 2 passes only if:

1. state persists durably;
2. consequential events are append-only and auditable;
3. all seven tools have strict typed contracts;
4. content access is bounded and authorized;
5. structurally invalid packages cannot be saved;
6. validation is non-mutating and honest about semantic coverage;
7. patches are bounded, idempotent, and audited;
8. semantic-risk patches require review;
9. finalization is blocked by hard errors/review;
10. abstention works;
11. tools do not prescribe the full future workflow;
12. no tool calls a model;
13. CF5 remains unchanged and green;
14. no production route imports this layer;
15. CF6 is not flattened into a legacy schema.

## Final report

Report:

1. preflight results;
2. exact files created/modified;
3. migrations and rollback;
4. persisted state/event schemas;
5. CF6 semantic-core schema;
6. each tool’s input/output/boundary/side effects;
7. state-transition table;
8. validation coverage matrix;
9. patch safety and review triggers;
10. idempotency strategy;
11. exact test results;
12. CF5 regression result;
13. deviations from the Integration Map;
14. gaps deferred to Milestone 3;
15. recommendation: proceed, repair, or stop.

Then stop. Do not implement Milestone 3.
