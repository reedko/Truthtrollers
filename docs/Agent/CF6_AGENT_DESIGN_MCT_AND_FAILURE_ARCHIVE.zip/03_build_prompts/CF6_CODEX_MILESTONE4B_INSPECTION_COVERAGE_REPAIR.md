# Codex Execution Prompt — CF6 Milestone 4B
## Repair Inspection Collapse Before Any More Blind Runs

Work from the VeriStrata repository root.

Do not run F02, F06, or F08 yet.

The first live F03 run already established the failure:

- source contained 404 units;
- the agent inspected only U0001–U0022;
- it drafted after the first 15 units;
- it never inspected later sections;
- it never searched;
- it finalized immediately after a `THIN_PORTFOLIO` warning;
- the final package omitted most of the article.

This is sufficient evidence of **premature local anchoring and inspection collapse**. Do not spend additional live tokens reconfirming it.

## Objective

Repair only the inspection-planning and finalization-coverage failure.

Do not tune attribution, atomicity, supplier assignment, challenged treatment, or claim wording yet.

## Required design

Add a persisted, auditable article-wide inspection plan derived from `get_content_map`.

The plan must identify major structural regions, for example:

```ts
type ContentRegionInspection = {
  regionId: string;
  heading: string | null;
  startUnitId: string;
  endUnitId: string;
  unitCount: number;
  status:
    | "uninspected"
    | "sampled"
    | "inspected"
    | "excluded";
  sampledUnitIds: string[];
  candidateBearing:
    | "unknown"
    | "likely"
    | "unlikely";
  dispositionReason: string | null;
};
```

Use repository naming conventions, but preserve the meaning.

## Behavioral rule

Before the agent may finalize:

1. it must obtain the content map;
2. every major region must be either:
   - sampled or inspected; or
   - explicitly excluded with a reason;
3. no major region may remain `uninspected`;
4. the agent must have inspected enough of each likely claim-bearing region to justify its portfolio;
5. all exclusions must be persisted and visible in the final audit.

Do not require reading every unit sequentially.

The model must still choose:

- which units to sample;
- whether a region is likely claim-bearing;
- whether more inspection is needed;
- which regions can be excluded;
- when coverage is sufficient.

The host may enforce only procedural completeness, not semantic completeness.

## Efficient sampling

For long regions, permit bounded sampling such as:

- first units;
- middle units;
- final units;
- units found through local search;
- additional units selected after a sample reveals claim-bearing content.

Do not hard-code one universal sampling recipe.

The agent should be encouraged to inspect at least one representative slice from every major region before drafting a final package.

## Tool and state changes

Prefer modifying the accepted tools rather than adding a new generic tool.

Expected changes may include:

- `get_content_map` returns explicit major regions and current inspection status;
- `read_source_units` updates region coverage;
- ClaimFoundry state persists region-inspection records;
- validation reports an `UNINSPECTED_MAJOR_REGION` hard finding;
- finalization blocks while any major region remains uninspected and undispositioned;
- final review artifacts show region coverage.

Do not make `THIN_PORTFOLIO` itself a hard error. A short article can legitimately have fewer than five claims.

The hard gate is unexplained uninspected content, not claim count.

## Instruction change

Make one narrow instruction-version change only.

Add language equivalent to:

```text
Before treating a package as complete, establish article-wide coverage.

Use the content map to identify every major structural region. Inspect a
representative portion of each region, and inspect claim-bearing regions more
deeply. Do not infer the article's full thesis or claim portfolio from its
opening section.

Every major region must be inspected or explicitly excluded with a recorded
reason before finalization. A locally coherent package is not complete when
substantial source regions remain unseen.
```

Bump the instruction version once.

Do not rewrite the rest of the manager instruction.

## Offline tests

Add tests proving:

- content regions are derived deterministically from the content map;
- inspection status persists;
- reading units updates the correct region;
- no major region may remain uninspected at finalization;
- explicit exclusion requires a non-empty reason;
- terminal finalization is blocked by uncovered regions;
- short content with full coverage may finalize with fewer than five claims;
- the runner still does not prescribe the full inspection order;
- the agent remains free to choose samples and deeper reads.

All prior tests must remain green.

## Live verification

After offline tests pass, run exactly one live F03 rerun under the new instruction version.

Do not run F02, F06, or F08 yet.

Compare only:

- regions inspected/dispositioned;
- units inspected;
- claim count;
- dispositions;
- whether later article sections were reached;
- whether finalization was blocked until coverage completed;
- tokens;
- latency;
- terminal status.

Do not tune again during the run.

## Token-safety requirement

Before the live rerun, estimate the maximum token cost from:

- model-turn budget;
- tool-output limits;
- expected region samples.

If the projected maximum is materially larger than the original F03 run, stop and redesign the sampling/summary payload before running.

The repair should improve coverage without requiring full-article text in the model context.

## Hard prohibitions

Do not:

- run three blind fixtures;
- increase model-turn or tool-call budgets;
- switch models;
- add a mandatory sequential full-article read;
- add external search;
- add subagents;
- tune any failure class other than inspection collapse;
- encode F03 expected answers;
- alter CF5;
- add routes or EvidenceRun;
- commit.

## Acceptance

Milestone 4B passes only if:

1. major content regions are explicit and persisted;
2. every region is inspected or dispositioned before finalization;
3. finalization blocks on unexplained uninspected regions;
4. the agent still chooses its own inspection path;
5. the live F03 rerun reaches beyond the opening section;
6. token use remains bounded and materially justified;
7. all prior tests remain green;
8. no unrelated semantic tuning is introduced.

## Final report

Report:

1. exact region model;
2. exact instruction diff;
3. files changed;
4. offline test results;
5. pre-run token estimate;
6. live F03 trajectory;
7. region coverage before versus after;
8. token/latency before versus after;
9. semantic defects still remaining;
10. recommendation:
   - accept coverage repair and proceed to blind F02/F06/F08 evaluation;
   - repair coverage mechanism;
   - stop.

Then stop.
