# Codex Diagnostic and Repair Prompt — CF6 Token Economics Before Further Live Runs

Do not run another live fixture yet.

The first F03 manager-agent run consumed:

- 135,817 input tokens
- 4,263 output tokens
- 140,080 total tokens

It inspected only U0001–U0022 of a 404-unit article and produced three claims. Prior non-agentic article processing routinely completed comparable work at roughly 15,000 tokens. A roughly 9–10× token increase for worse semantic coverage is not acceptable as the normal cost of “agentic” processing.

The OpenAI Agents SDK reports `inputTokens` as the aggregate across all model requests in the run. Determine exactly why this run accumulated 135,817 input tokens before making any semantic or coverage repair.

## Phase 1: factual audit only

Do not change code during Phase 1.

Report the following from the accepted Milestone 3 implementation and F03 artifacts:

1. Exact number of model requests.
2. Per-request:
   - input tokens;
   - cached input tokens, where exposed;
   - uncached input tokens, where exposed;
   - output tokens;
   - request/response ID;
   - model turn number;
   - tool call(s) following that request.
3. Extract per-request usage from `RunResult.rawResponses`, `ModelResponse.usage`, `RequestUsage`, or the exact supported API of the installed SDK.
4. Identify the conversation-state mechanism actually used:
   - full client-managed history;
   - SDK session;
   - `conversationId`;
   - `previousResponseId`;
   - another mechanism;
   - or an accidental combination.
5. Confirm whether client-managed history and server-managed continuation are being mixed. The Agents SDK warns that mixing them can duplicate context.
6. For each model request, estimate or measure the model-visible size of:
   - manager instructions;
   - tool definitions and JSON schemas;
   - prior assistant/model items;
   - prior tool-call arguments;
   - prior tool outputs;
   - `get_content_map` result;
   - each `read_source_units` result;
   - each complete `save_working_package` argument;
   - validation reports;
   - errors and retries.
7. Produce a cumulative-context table showing why input tokens grew from request to request.
8. Identify the three largest repeated payload classes.
9. Explain whether the 140,080 total is primarily:
   - necessary source inspection;
   - repeated conversation history;
   - repeated full-package serialization;
   - oversized tool schemas/results;
   - retries/errors;
   - reasoning/output;
   - or another cause.
10. Compare the agent run with the approximately 15,000-token prior baseline. Do not dismiss the difference as an unavoidable cost of agency.

Persist this audit as:

```text
artifacts/claim-foundry/cf6-agent/token-audit-f03/
  per-request-usage.json
  model-input-size-breakdown.json
  cumulative-context.md
  token-audit.md
```

Do not include secrets or full article text in the audit report.

## Phase 2: propose a bounded repair

After the factual audit, propose the smallest architecture changes that reduce repeated model context while preserving genuine model-selected tool use.

Evaluate at least:

1. `callModelInputFilter`
   - The installed Agents SDK supports filtering model input before every call.
   - Determine whether old bulky tool outputs and superseded full-package arguments can be replaced with compact, lossless state summaries.
2. Conversation-state mechanism
   - Determine whether the current runner is replaying full history unnecessarily.
   - Compare client-managed history, session, `conversationId`, and `previousResponseId`.
   - Do not claim that server-managed state reduces billed tokens unless the measured usage proves it.
3. Tool-result shaping
   - Keep full durable data in MySQL/audit events.
   - Return only what the model needs for its next decision.
   - Use SDK-only custom metadata for audit data that need not be replayed to the model, where supported.
4. Working-package mutation
   - The model currently sends complete package replacements repeatedly.
   - Determine how much token cost comes from repeated full package arguments.
   - Propose a bounded drafting/update contract that avoids replaying superseded full packages without enabling arbitrary JSON mutation.
5. Source inspection payloads
   - Preserve exact source text currently needed by the model.
   - Remove or compact old source-unit payloads only after their relevant semantic notes, claim drafts, and grounding IDs are safely represented in persisted state.
6. Tool schemas
   - Measure schema token cost.
   - Simplify descriptions or schemas only when semantic and safety constraints remain intact.
7. Context compaction
   - Evaluate SDK-supported history compaction or `contextManagement`.
   - Do not add model-generated compaction that can silently lose grounding or attribution unless the loss risks are explicitly controlled and tested.

## Required design principle

Durable audit state and model-visible conversational state are different things.

MySQL must retain:

- full tool arguments/results or hashes;
- source inspections;
- package versions;
- validation;
- repairs;
- trajectory.

The model should receive only the current decision-relevant slice:

- compact run/coverage state;
- current package summary or relevant claim rows;
- active validation findings;
- relevant source units;
- remaining budgets.

Do not repeatedly replay the entire durable audit ledger to the model.

## Token gates before another live run

Do not run F03 again until an offline/request-level projection demonstrates:

- expected total input tokens no higher than 45,000;
- target total input tokens near or below 30,000;
- no single later model request contains unbounded accumulated history;
- all removed history is either superseded, durably persisted, or replaced by a typed compact representation;
- exact grounding text remains available when needed;
- the agent still chooses tools dynamically.

If the design cannot plausibly bring the run below 45,000 input tokens, stop and recommend whether:

- the tool/action design must change;
- the manager loop should be divided into bounded agent phases;
- a larger one-shot semantic inventory followed by agentic repair would be more economical;
- or the agent approach should be rejected for this task.

Do not protect the current architecture merely because Milestones 1–3 passed mechanically.

## Phase 3: implementation, only after audit approval

Do not implement Phase 3 until the audit and proposed repair are reviewed.

When authorized later, the repair must:

- preserve SDK-managed agent choice;
- preserve MySQL auditability;
- preserve exact source grounding;
- add per-request usage recording permanently;
- add a hard total-input-token budget;
- stop before runaway cumulative context;
- retain all existing safety, MySQL, tool, and CF5 tests.

## Final response

Return:

1. the per-request token table;
2. the dominant causes of the 135,817 input tokens;
3. the exact conversation-state mechanism;
4. any duplicated-context bug;
5. proposed changes ranked by expected token savings and semantic risk;
6. projected token total after each change;
7. recommendation:
   - repair current manager loop;
   - redesign the action/state boundary;
   - use a hybrid one-shot + agentic repair architecture;
   - or stop the agent approach.

Then stop. Do not edit code or run another fixture.
