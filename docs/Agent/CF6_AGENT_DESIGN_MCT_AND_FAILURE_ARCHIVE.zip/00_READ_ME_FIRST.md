# ClaimFoundry CF6 Agent Attempt Archive

Date assembled: 2026-07-27

This archive preserves the governing design records, the prompts used to build and test the first CF6 agent attempt, the architecture-reset proposal, the failure report, and the primary live-run/token-audit evidence used in those documents.

## Directory guide

- `01_governing/` — MCT, repository integration map, semantic/output decisions, acceptance rubric, failure corpus, retained TM5 design provenance, and the legacy CF1 package reference.
- `02_design_and_review/` — the architecture-reset design document and the first-agent-attempt failure report.
- `03_build_prompts/` — the Codex milestone and diagnostic prompts that defined the attempted implementation and its repairs.
- `04_live_run_evidence/` — the F03 final package, run configuration, source manifest, trajectory, validation, usage, and token-economics audit.
- `05_code_evidence/` — user-provided repository excerpts used to determine that the content map was complete and that `maxBlocks` was a hard ceiling rather than pagination.
- `SHA256SUMS.txt` — integrity hashes for every archived file.

## Governing interpretation

The archive records the first CF6 manager-loop attempt as:

- mechanically successful infrastructure;
- semantically unsuccessful as a product run;
- economically unsuccessful under both the live full-history design and the later relevance-neutral lossless projection;
- insufficient evidence to reject all model-directed or agentic ClaimFoundry architectures;
- sufficient evidence to freeze the particular whole-article conversational manager loop that was attempted.

The architecture-reset document is a proposal, not a proven solution. The failure report evaluates whether it directly addresses the recorded failures and defines a minimal experiment and kill criteria.
