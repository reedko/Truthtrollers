# CF6 F03 cumulative context

| Model turn | Preceding tool | Estimated serialized payload tokens | Exact provider input tokens |
|---:|---|---:|---:|
| 1 | initial | 6777 | not retained |
| 2 | get_content_map | 9912 | not retained |
| 3 | read_source_units | 11295 | not retained |
| 4 | save_working_package | 11898 | not retained |
| 5 | read_source_units | 13372 | not retained |
| 6 | save_working_package | 14330 | not retained |
| 7 | read_source_units | 14736 | not retained |
| 8 | save_working_package | 15991 | not retained |
| 9 | save_working_package | 17284 | not retained |
| 10 | validate_working_package | 17621 | not retained |
| 11 | finalize_claim_package | 17823 | 16804 |

The estimate counts repository-visible serialized content with the model tokenizer. It excludes protocol framing and unretained assistant items, so it is directional. Turn 11 is the only request with recoverable exact provider usage.
