# CF6 F03 token economics audit

## Executive finding

The 135,817 input tokens were not necessary source inspection. The run used the SDK's client-managed full-history mechanism and replayed an increasingly large transcript on every request. The transcript included a 6,162-token tool-schema bundle, a 3,100-token content-map result, three exact-text source reads, and four complete package-save arguments.

Only 22 of 404 source units were inspected. Model output was 4,263 tokens, so reasoning/output was not the dominant cost.

## What can be established exactly

- Model requests: **11**
- Aggregate usage: **135,817 input; 4,263 output; 140,080 total**
- Model: `gpt-4.1-mini-2025-04-14`
- Final request: **16,804 input; 16,512 cached input; 292 uncached input; 184 output**
- Final response ID: `resp_0457ac390259308e006a6765a30540819a90a8861d3544a4d6`
- Final response `previous_response_id`: `null`
- Final response `conversation`: `null`

Milestone 3 read `RunResult.rawResponses` only to count them. It then discarded the response objects and `Usage.requestUsageEntries`. Trace export was skipped because the tracing exporter had no configured key. Only aggregate usage and the last response ID were retained. Consequently, exact usage, cache details, output usage, and response IDs for turns 1–10 are unrecoverable. They are left `null` in `per-request-usage.json`; inventing an exact table would be false.

## Conversation-state mechanism

The runner supplied:

- a plain initial input string;
- `maxTurns`;
- an abort signal.

It did not supply a session, `conversationId`, `previousResponseId`, or `callModelInputFilter`. The installed SDK accumulated the initial input plus every model item, tool call, and tool output in its in-memory run state and passed that growing input list to each Responses API call.

This was **full client-managed history only**. Client-managed history and server-managed continuation were not mixed. Therefore there was no duplicated-context bug involving `previousResponseId` or a conversation. The defect was the unbounded client-managed replay itself.

Using a session would persist/combine history but would not inherently reduce model input. A conversation or `previousResponseId` would move continuation state server-side, but no token saving should be claimed without measurement: retained context can still be included in billed input. Mixing either mechanism with full client history would be prohibited.

## Payload measurements

Repository-visible payloads were tokenized with `tiktoken`'s `gpt-4.1-mini` encoding. These are serialized-payload estimates rather than provider usage because protocol framing and old assistant items were not retained.

Fixed content sent on every request:

| Payload | Tokens/request | Eleven-request exposure |
|---|---:|---:|
| Manager instructions | 585 | 6,435 |
| Seven tool definitions and schemas | 6,162 | 67,782 |
| Completion schema | 207 | 2,277 |
| Initial request | 30 | 330 |

The two largest schemas were:

| Tool | Schema tokens | Eleven-request exposure |
|---|---:|---:|
| `apply_package_patch` | 3,604 | 39,644 |
| `save_working_package` | 1,801 | 19,811 |

Together those two unused-or-rarely-used definitions account for approximately 59,455 serialized tokens across the run. `apply_package_patch` was never called.

History payloads:

| Class | One-copy tokens | Estimated cumulative replay contribution |
|---|---:|---:|
| Content-map output | 3,100 | 31,150 |
| Three source-read outputs | 2,997 | 24,375 |
| Four complete package arguments | 3,668 | 19,051 |

These contributions overlap with provider framing/cache behavior and should not be added as an exact bill. They identify what was repeatedly rendered. The reconstructed final payload was 17,823 tokens versus the provider's exact 16,804, a roughly 6% overestimate. The reconstructed eleven-request sum was 151,039 versus the exact 135,817 aggregate, an approximately 11% overestimate.

The three largest repeated payload classes were:

1. Tool definitions—especially the 3,604-token patch schema and 1,801-token full-package schema.
2. The full content map retained after its first use.
3. Exact source outputs and superseded complete-package arguments retained for every later decision.

## Comparison with the prior baseline

The run used approximately **9.1×** the roughly 15,000-token prior baseline while inspecting only 5.4% of the article's source units. This is not an unavoidable agency premium. It is an action/state-boundary failure: durable audit history was treated as model-visible conversational memory.

## Bounded repair proposal

No implementation or new live run is authorized by this audit.

### 1. Add permanent per-request accounting and a hard input gate

Persist every `ModelResponse.id`, `RequestUsage`, cached tokens, and the tool decisions following each response. Enforce a projected and observed total-input-token ceiling before each subsequent request.

- Expected saving: none by itself; prevents another runaway run.
- Semantic risk: low.
- Projected total alone: unchanged, but stopped at the configured ceiling.

### 2. Add a deterministic `callModelInputFilter`

Before every call, construct model-visible input from persisted canonical state:

- compact run, coverage, and remaining-budget summary;
- current package summary or only relevant claim rows;
- active validation findings;
- the latest decision-relevant source units;
- the most recent tool result/error.

Drop complete superseded tool-call/output pairs. Old source text may be removed only after its grounding IDs and derived claim/note state are persisted; it remains rereadable through `read_source_units`. The filter must never use a model-generated lossy summary.

- Expected saving from this run's history replay: approximately 35,000–55,000 input tokens.
- Semantic risk: medium; controlled by deterministic retention rules and reread tests.
- Projected total without schema repair: approximately 75,000–95,000, still unacceptable.

### 3. Redesign the two bulky action schemas

The 5,405-token combined save/patch schemas dominate fixed request cost. Preserve the same domain validation and allow-listed operations, but avoid advertising both full recursive schemas on every model request.

Preferred bounded options:

- expose tools only while their legal action is relevant, using the SDK's `isEnabled` support and persisted state—not a scripted full sequence;
- accept a shallow typed envelope whose package/patch payload is parsed by the existing repository-owned Zod schema inside the tool;
- replace repeated full package replacements with bounded claim-row upserts/removals and deterministic identity/audit fields filled from authorized context.

The model must still choose among multiple currently legal actions. MySQL retains complete arguments, results, versions, and hashes.

- Expected saving: approximately 40,000–60,000 input tokens on an eleven-turn run, primarily by avoiding repeated patch/save schema exposure.
- Semantic risk: medium for state-based exposure; medium-high for a revised drafting contract.
- Projected total combined with the input filter: **28,000–42,000**.

### 4. Compact content-map and tool results

Return a paged structural map or section summaries rather than all unit IDs in one 3,100-token result. Retain the full map in MySQL. Continue returning exact text for the currently requested units, but remove the full `MutationResult.state` shape in favor of a typed compact decision summary.

- Expected saving: approximately 8,000–20,000 tokens depending on turn count.
- Semantic risk: low for output-envelope removal; medium for map pagination.
- Projected combined target: **24,000–36,000**.

### 5. Do not rely on server-managed continuation as the repair

Sessions, `conversationId`, and `previousResponseId` should be evaluated in isolated request-level tests, but none is credited with savings until measured provider usage proves it. Do not combine server continuation with replayed client history.

- Credited saving: zero.
- Semantic risk: low if isolated; duplication risk if mixed.

### 6. Avoid generic model-generated compaction

SDK `contextManagement`/compaction may reduce rendered history but can silently lose source grounding, attribution, or treatment. It is not the first repair. If later evaluated, compacted content must be reconstructible from typed persisted state and exact source rereads.

- Credited saving: zero until measured.
- Semantic risk: high for this domain.

## Token gate and recommendation

`callModelInputFilter` alone cannot meet the 45,000-token gate because the current seven-tool schema bundle costs about 6,162 tokens per request. The action/schema boundary must also change.

The current manager loop remains repairable if deterministic input filtering, state-dependent schema exposure or shallow bounded payloads, compact tool results, permanent per-request usage, and a hard input budget are implemented together. The offline projection is 28,000–42,000 input tokens, beneath the 45,000 ceiling and plausibly near the 30,000 target.

If request-level offline projection after implementation remains above 45,000, do not run F03. At that point prefer a hybrid architecture: one bounded semantic inventory over source chunks followed by SDK-managed validation/repair/finalization. Reject the current unconstrained full-history manager design as the normal production path.
