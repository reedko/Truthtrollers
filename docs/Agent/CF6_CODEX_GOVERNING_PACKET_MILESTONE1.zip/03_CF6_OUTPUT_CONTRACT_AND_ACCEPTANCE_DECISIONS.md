# CF6 Output Contract and Acceptance Decisions

**Status:** Governing user decision record  
**Date:** 2026-07-27  
**Scope:** Cleaned from the recovered CF6 acceptance/output form. Blank fields, unused placeholders, and the unfinished “blind Codex” grader section have been removed.

## 1. Product Purpose

ClaimFoundry CF6 will produce:

> The smallest complete set of grounded, independently investigable substantive representations needed to evaluate the content and find evidence bearing directly on the content.

The system must produce claims that are not compound, are searchable as evidence targets, and preserve the information needed to find evidence with direct bearing. Any study or named work implicit in a claim should be readily identifiable. The package must also show whether the content adopts/supports the proposition or presents it for rebuttal.

EvidenceRun is not presently available as the operative downstream system. CF6 must therefore preserve an evidence-ready handoff without depending on ER1 to reconstruct missing semantics.

## 2. Contract Strategy

CF6 will create a **new semantic core with a compatibility wrapper or projection**.

The legacy `cf1.claimPackage.v1` may remain an integration envelope or persistence target, but it does not define the final CF6 semantic model.

Downstream evidence retrieval must never mutate ClaimFoundry’s canonical target text.

## 3. Persisted Artifacts

Persist all of the following:

- normalized source and citation sidecars;
- semantic inventory;
- theme and thesis map;
- candidate assertions;
- canonicalization and deduplication map;
- atomicity and critic findings;
- portfolio selection report;
- validation and repair history;
- final canonical package;
- tool trajectory and run audit.

## 4. Required Selected-Claim Fields

Every selected claim must preserve:

- `surfaceStatement`
- `substantiveAssertion`
- `attributionLayers[]`
- `contentSupplier`
- `contentSupplierKind`
- `reportingVoice`
- `articleTreatment`
- `polarity`
- `scope`
- `attributionUnitIds[]`
- `substantiveGroundingUnitIds[]`
- `verificationTarget`
- `themeIds[]`
- `materiality`
- `selectionRationale`
- `identityHints`

## 5. Evidence-Ready Projection

The compact evidence-facing projection should contain:

- `targetId`
- `canonicalTargetText`
- `verificationTarget`
- `scopeAndQualifiers`
- `contentSupplier`
- `identityHints`
- `mustMatch`
- `usefulSourceRoles`
- `rejectionBoundaries`
- `groundingReferences`

## 6. Attribution and Provenance

- Expose no more than **three attribution layers**.
- When attribution recursion exceeds the cap, abstain rather than silently flattening the chain.
- When the supplier cannot be resolved without guessing, record the supplier as `unknown`.
- Never infer a supplier merely to avoid an unknown value.
- Create a separate attribution or provenance target when the content materially relies on:
  - whether the attribution occurred;
  - whether the identified source exists; or
  - whether the source actually made the statement.

## 7. Grounding

Grounding remains one acceptance area rather than two separately promoted dimensions, but it contains two required tests.

### Structural grounding integrity

All source-unit IDs must exist in the authorized content. Offsets and quoted spans must be exact. Lineage must be complete. No foreign or fabricated grounding may appear.

- Threshold: **100%**
- Owner: deterministic host validator

### Semantic grounding adequacy

The cited units must substantively support the selected assertion without:

- unsupported synthesis;
- polarity reversal;
- attribution substitution; or
- material loss of scope.

Semantic adequacy must be assessed through calibrated semantic review. Its numeric threshold should be set only after the grader has itself been calibrated.

## 8. Portfolio Policy

- Hard ceiling: **15**
- Hard floor: **0**
- Flag portfolios with fewer than **5**
- Never pad an article to hit a count
- A genuinely thin portfolio is acceptable when the source is genuinely thin

Every candidate that is removed, declined, not selected, merged, or deferred must retain:

- candidate ID;
- decision;
- reason;
- validator finding or selection rationale;
- source-unit IDs;
- whether the omission is material;
- whether human review is required.

## 9. Abstention Policy

Abstention is warranted when:

- a referent cannot be resolved;
- source support is insufficient;
- attribution cannot be assigned without guessing;
- the claim cannot be made independently verdictable without changing its meaning;
- the run exhausts its budget after required source inspection; or
- the article genuinely contains no additional material target.

Abstention must be explicit and inspectable. Silent drops are prohibited.

## 10. Repair Policy

Permitted bounded repair operations:

- add;
- remove;
- replace;
- split;
- merge;
- change treatment;
- change provenance;
- resolve reference;
- change scope;
- change polarity.

The agent should describe and request these operations as the run proceeds.

Limits:

- maximum one repair round per defect;
- maximum two repair rounds per complete run.

When a repair may have changed meaning, pause for human review. Do not accept a cleaner surface merely because it reads better.

## 11. Blocking Acceptance Gates

The following are blocking:

1. **D1 Central representation recovery**
2. **D3 Independent verdictability**
3. **D5 Challenged-class treatment accuracy**
4. **D6 Structural grounding integrity**
5. **D10 Zero repair corruption**

Overall promotion requires:

> CF6 must pass every blocking gate, meet or exceed CF5 on every remaining dimension, and strictly outperform CF5 on crux recovery, material omission, and independent verdictability.

## 12. Failure Corpus

Use `CF6_FAILURE_CORPUS_MANIFEST.md` as the governing failure-corpus record.

No additional manually entered failure rows are required. The manifest already defines:

- active regressions;
- validator fixtures;
- deterministic repair fixtures;
- infrastructure tests;
- architecture history;
- obsolete mechanisms;
- promotion and retirement rules;
- normalized corpus layout.

The active corpus is not all historical runs. It is the reduced, reviewed set identified by the manifest.

## 13. Removed From the Form

The following were intentionally removed from this decision record:

- blank dimension-specific notes;
- blank failure-data location fields;
- the empty manual failure-case row;
- blank repository and human-question fields;
- unused final notes;
- the unfinished “blind Codex” grader identity and calibration section.

Codex was the coding and testing assistant, not a separately defined grading institution.

## 14. Verification-Target Rule

The default verification target is the **deepest independently verifiable substantive proposition**, not the surface reporting or attribution event.

Preserve these separately:

- the surface statement;
- reporting voice;
- attribution layers;
- content supplier; and
- the substantive proposition to be investigated.

Ordinarily:

> “X said, revealed, or claimed P”

produces **P** as the substantive verification target. The fact that X made the statement remains preserved as attribution and provenance rather than replacing P.

Create a separate attribution or provenance target only when the content materially concerns:

- whether the source made the statement;
- the source’s history of making such statements;
- the source’s credibility or reliability;
- authorship or disclosure;
- the existence or identity of the source; or
- another source-level fact that is itself part of the content’s evaluative burden.

For example, in an article examining false or misleading claims repeatedly made by a whistleblower, the whistleblower’s statements and statement history may themselves be the substantive object of evaluation.

This resolves the final output-contract ambiguity and may now govern the CF6 claim schema.
