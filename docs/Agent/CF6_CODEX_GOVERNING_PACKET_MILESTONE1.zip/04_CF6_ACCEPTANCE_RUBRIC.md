# CF6_ACCEPTANCE_RUBRIC.md
Date: 2026-07-26
Status: Canonical acceptance definition for the CF6 claim-extraction agent.

Purpose: define, measurably, what "better than CF5" means — so the agent cannot pass
mechanically while producing a bad package. Every dimension is scored against SEALED gold
keys built blind by Codex, never from run output. Each carries the scoring guardrail the
MCT paid for; the guardrails are not optional and exist because each one was a real,
costly mistake earlier in this project.

---

## 0. Non-negotiable measurement rules (apply to every dimension below)

These are the scars. Violating any of them invalidates the score, not just the run.

R0.1  **Sealed blind keys only.** Gold keys are authored by Codex from the article and
      fact-checking judgment, sealed with a content hash, never derived from any CF4/CF5/
      CF6 run output. A key edited after sealing invalidates all prior scores against it.

R0.2  **Fix the ruler before the run.** Any metric that computes a match (entailment,
      overlap) must itself be calibrated against human labels and report its own
      precision/recall before it is used to grade the pipeline. A grader that has not been
      validated is not evidence.

R0.3  **One-directional entailment for recall.** A gold is recalled iff a candidate
      ENTAILS the gold (candidate->gold >= tau, tau calibrated, currently 0.70).
      Gold->candidate (over-breadth) is reported SEPARATELY as an atomicity signal and is
      NEVER part of the recall gate. Bidirectional/min entailment is forbidden as a recall
      metric — it punishes correct-but-broader captures.

R0.4  **Union cap is fixed at 3 and never raised to pass.** A gold whose content requires
      >3 candidates to entail is either a genuine coverage gap OR a compound gold that
      Codex must split on SUBSTANCE (independently checkable facts), never a reason to
      raise the cap. Raising the cap to light up a gate is a rubric violation.

R0.5  **Minority classes reported separately, never inside an aggregate.** Any accuracy
      number for a labeled dimension (treatment, thesisEffect) MUST break out the minority
      class (challenged; weakens/no_effect) as its own figure. A 93% aggregate that hides
      0% minority recall is a failing score, not a passing one.

R0.6  **Abstention is a first-class outcome, not a miss.** When the agent declines (thin
      portfolio, unresolvable referent, cannot place an assertion), that is recorded and
      scored as correct behavior WHERE the gold agrees abstention was warranted. Forcing an
      output to avoid an abstention is a failure mode, not a success.

R0.7  **Human-in-eval only through Codex, blind.** Any dimension requiring human judgment
      (compound-substance rulings, false-negative triage) is performed by Codex, the
      independent verifier, never by the party that built the pipeline. Fabicles does not
      grade its own extractor.

R0.8  **Read the raw before trusting the verdict.** For any gate failure, the raw
      selection/inventory records must be human-readable and inspected directly before a
      redesign is triggered. A computed verdict that contradicts the raw records (e.g.
      "selected but not extracted") is a grader bug, not a pipeline result.

---

## 1. The twelve dimensions

Each dimension: definition, measurement, guardrail, and the pass bar relative to CF5.
"Better than CF5" = meets or exceeds CF5 on every dimension AND strictly exceeds on at
least the crux/omission/verdictability set (1, 2, 3), which are the ones that make the
package actually useful.

### D1 — Central representation recovery (CRUX GATE — hard, blocking)
Definition: the article's load-bearing claim(s) — the crux, flagged in the sealed key —
appear in the final selected portfolio.
Measurement: for each fixture, crux-flagged golds recalled (R0.3) AND selected, over 5
repeats. Report per-crux, per-repeat.
Guardrail: this is the dimension PageRank and the compound-anchor both failed silently.
It is a NAMED GATE, not an average. A crux recovered in 3/5 repeats is not "60% good" —
it is UNSTABLE and fails.
Pass bar: every crux-flagged gold selected in >= 4/5 repeats on every fixture. No
exceptions traded against other dimensions. CF5 baseline: crux recovery was not reliably
achieved — any stable improvement here is the primary justification for CF6.

### D2 — Material omission rate
Definition: fraction of sealed must-select golds NOT recovered in the portfolio.
Measurement: (must-selects not selected) / (must-selects), per fixture, mean over repeats.
Split REAL_GAP (content absent or unrecoverable) from FALSE_NEG (present, grader missed) via
Codex triage (R0.7). Only REAL_GAP counts as omission.
Guardrail: R0.3 (one-directional). Do not let lexical overlap or bidirectional NLI mask an
omission — the union-scoring saga proved lexical hides dropped conjuncts.
Pass bar: material omission rate <= CF5's, with documented, defensible exceptions only
(cap-bound multi-unit assertions; proven-unsafe demonstrative composition). Every exception
named in the run report.

### D3 — Independent verdictability
Definition: each selected assertion is checkable by an external fact-checker WITHOUT reading
the article — self-contained, de-attributed, referents resolved.
Measurement: Codex scores each portfolio assertion yes/no on "could a checker verify this as
written." Report the fraction and every no with reason.
Guardrail: this is where attribution fusion and unresolved referents hide. An assertion that
reads "Thompson revealed X" or "this cumulative load" is NOT independently verdictable even
if semantically present. Score the SURFACE a checker would act on, not the latent meaning.
Pass bar: >= 90% independently verdictable, and strictly >= CF5. The remainder must be
abstentions or documented limits, not silent bad surfaces.

### D4 — Attribution accuracy
Definition: assertionSource (name + kind) is the ORIGINATOR, not the reporter; kind matches
the named entity; recursion (X said Y claimed Z) resolves to the innermost originator.
Measurement: per selected assertion, name-match and kind-match against sealed key. Report
BOTH separately. "unknown" where the key says unknown is CORRECT (abstention, R0.6).
Guardrail: a named entity NEVER receives article_voice (the CF3 name<->kind contradiction).
Overinterpretation (guessing a source the text doesn't support) counts as WRONG, not as a
near-miss.
Pass bar: usable-name-or-correct-abstention >= 70% (attribution is the historically weakest
dimension; do not set a bar the task can't meet, but do not hide the weakness in an
aggregate either). kind-match >= 90%. Both >= CF5.

### D5 — Treatment accuracy (minority-split mandatory)
Definition: articleTreatment (adopted | challenged | reported) correct against the key.
Measurement: per-class accuracy. Report `challenged` as its OWN figure (R0.5) — it is the
minority class and the one that matters for opponent handling.
Guardrail: the adopted->reported collapse (CF3) and the census over-firing both live here.
An aggregate treatment accuracy that hides `challenged` performance is a failing score by
R0.5. Cross-check: host discourse-feature prediction vs model; disagreements reported.
Pass bar: `challenged` precision AND recall >= 0.80; aggregate >= CF5; no class at 0.

### D6 — Grounding validity
Definition: every assertion's groundingUnitIds actually contain the assertion; source
lineage is exact; no unit IDs outside the article range.
Measurement: deterministic host check — 100% is achievable because this is syntactic.
Report any assertion whose grounding does not support it.
Guardrail: this is the one dimension that should be PERFECT, because it's deterministic. Any
failure here is a lineage bug, not a judgment call. No tolerance band.
Pass bar: 100% grounding validity. Lineage exact. == CF5 (CF5/CF4 already achieve this;
regression here is a hard stop).

### D7 — Portfolio economy
Definition: the portfolio is the load-bearing set, not padded and not starved. Size reflects
the article (emit-fewer-and-flag, ceiling 15, no floor, flag if < 5).
Measurement: portfolio size distribution per fixture; fraction of selected assertions that
are must-selects or cover a distinct sub-thesis vs. filler.
Guardrail: R0.6. A short honest portfolio on a thin article is CORRECT, not a shortfall.
Padding to a target is the failure. Do NOT gate on hitting a count.
Pass bar: no selected assertion is filler (Codex: every selection places in the argument);
size within [flag-if-<5, 15]; strictly LEANER than CF5 where CF5 padded.

### D8 — Duplicate / redundancy rate
Definition: no two selected assertions are near-duplicates or resolved by substantially the
same evidence.
Measurement: pairwise NLI within the portfolio; flag mutual-entailment pairs. Report count.
Guardrail: sub-span duplicates (C0101 vs C0102 headless fragment) must be caught — the
inventory is full of them. A portfolio that selects both a full assertion and its own
sub-span is redundant AND picks the weaker surface.
Pass bar: zero mutual-entailment pairs in the portfolio; <= CF5.

### D9 — Stability across repeats
Definition: the same article yields substantially the same portfolio across runs.
Measurement: over 5 repeats, report (a) crux stability (D1, must be >=4/5), (b) core-set
Jaccard across repeats, (c) size variance.
Guardrail: selection is a model call, so variance is IN SCOPE and must be measured, not
assumed away. The F06 5->10 swing on identical input is the failure this catches. If
stability is low, the fix is repeats-and-vote or a shorter/filtered input, NOT prompt
tuning toward a fake determinism.
Pass bar: crux stability >= 4/5 (== D1); core-set Jaccard >= 0.6 across repeats; size
variance within +/-3. Better than CF5's observed swing.

### D10 — Repair effectiveness
Definition: when a stage flags a repairable defect (unresolved referent, fragment,
non-entailed candidate), the repair improves the package without introducing corruption.
Measurement: for each repair class, before/after on the affected assertions; corruption
check (repair must not invent content or flip polarity — validate every repaired surface
against its source span).
Guardrail: repair is where invented content and the Antoniou-title corruption entered.
A repair that produces a cleaner-reading but WRONG surface is worse than no repair. Content-
preservation is a HARD validator, not a finding.
Pass bar: repairs strictly improve verdictability (D3) with zero introduced corruption;
any repair that can't guarantee content-preservation is disabled, not shipped.

### D11 — Cost and latency
Definition: end-to-end model spend and wall time per article.
Measurement: total tokens, call count, wall seconds, per fixture. Break out per stage.
Guardrail: cost is real but SUBORDINATE to D1-D3. A cheaper package that drops the crux is
not "more economical," it's broken. Never trade a crux gate for latency.
Pass bar: <= 120s wall, <= 40K tokens end-to-end (targets, not gates); report actuals;
must not exceed CF5 by more than the cost of the quality gains, stated explicitly.

### D12 — Transparent abstention
Definition: when the agent declines (thin portfolio, unresolvable content, low confidence),
it says so explicitly and the abstention is inspectable — what it declined and why.
Measurement: abstention log present and human-readable; each abstention classified by Codex
as warranted or unwarranted against the key.
Guardrail: R0.6. Silent forcing of output is the failure. An unwarranted abstention (declined
something it should have kept) is scored as an omission (D2); a warranted one is scored as
CORRECT. Both must be visible.
Pass bar: 100% of abstentions logged and inspectable; warranted-abstention rate reported;
zero silent drops (anything removed must appear in a finding).

---

## 2. Overall acceptance

CF6 is "better than CF5" iff, on all sealed fixtures (F02, F03, F06 minimum; promotion
requires the held-out set too):

- **Hard gates (blocking, no trading):** D1 crux gate (>=4/5 every crux), D6 grounding
  (100%), D5 `challenged` (>=0.80/0.80), D3 verdictability (>=90%), D10 zero introduced
  corruption.
- **Meets-or-exceeds CF5:** every remaining dimension, with any shortfall documented as a
  named, defensible limit (not a silent loss).
- **Strictly exceeds CF5:** on D1 (crux), D2 (omission), D3 (verdictability) — the three
  that make the package actually usable. If CF6 doesn't beat CF5 on these, it isn't better,
  whatever the mechanical numbers say.

A run report that does not present all twelve dimensions with their guardrails satisfied is
not an acceptance test — it is an anecdote. Aggregate-only reporting is rejected on sight
(R0.5).

## 3. What this rubric deliberately refuses to reward

- A high aggregate that hides a dead minority class.
- Recall bought with a loosened metric (bidirectional->one-directional drift, cap raise).
- A full portfolio bought by padding a thin article.
- A clean-reading assertion that is factually altered from its source (D10).
- A gate passed by editing a gold key after sealing (R0.1).
- Any number produced by a grader that hasn't itself been validated (R0.2).

These are the six ways this project previously fooled itself. The rubric exists to make each
one a rejected score rather than a celebrated one.