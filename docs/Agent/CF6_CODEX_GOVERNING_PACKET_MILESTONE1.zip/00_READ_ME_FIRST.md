# CF6 Codex Governing Packet

Use `08_CF6_CODEX_MILESTONE1_EXECUTION_PROMPT.md` as the execution prompt.

Governing hierarchy:
1. CF6 Real Agent Build MCT
2. CF6 Integration Map
3. CF6 Output Contract and Acceptance Decisions
4. CF6 Acceptance Rubric
5. CF6 Failure Corpus Manifest
6. TM5 Brain-First Spec as conceptual provenance
7. CF1 Claim Package reference as legacy executable-contract evidence only

Milestone 1 only:
- isolated OpenAI Agents SDK scaffold
- provider-neutral runtime boundary
- harmless typed smoke tool and smoke agent
- SDK-managed tool-loop test
- no CF5 changes
- no production integration
- no ClaimFoundry domain tools
- no commit
